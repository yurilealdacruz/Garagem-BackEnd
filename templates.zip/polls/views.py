from django.shortcuts import redirect
from django.http import JsonResponse
from .models import CarAction
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def entrada(request):
    if request.method == 'POST':
        CarAction.objects.create(action='entrada')
        return JsonResponse({'message': 'Entrada registrada com sucesso!'})
    return JsonResponse({'error': 'Método não permitido.'}, status=405)

@csrf_exempt
def saida(request):
    # Cria uma nova saída
    if request.method == 'POST':
        CarAction.objects.create(action='saida')
        return JsonResponse({'message': 'Saída registrada com sucesso!'})
    return JsonResponse({'error': 'Método não permitido.'}, status=405)


def carros_na_garagem(request):
    # Calcula o número de carros na garagem
    entradas = CarAction.objects.filter(action='entrada').count()
    saidas = CarAction.objects.filter(action='saida').count()
    carros_na_garagem = entradas - saidas
    return JsonResponse({'carros_na_garagem': carros_na_garagem})
