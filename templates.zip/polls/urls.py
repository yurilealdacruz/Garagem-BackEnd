# polls/urls.py

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path




urlpatterns = [
    path('entrada/', views.entrada, name='entrada'),
    path('saida/', views.saida, name='saida'),
    path('carros_na_garagem/', views.carros_na_garagem, name='carros_na_garagem'),
]

