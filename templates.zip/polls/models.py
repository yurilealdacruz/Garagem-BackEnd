from django.db import models

class CarAction(models.Model):
    ACTION_CHOICES = [
        ('entrada', 'Entrada'),
        ('saida', 'Saída'),
    ]
    action = models.CharField(max_length=7, choices=ACTION_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.action} - {self.timestamp}"
